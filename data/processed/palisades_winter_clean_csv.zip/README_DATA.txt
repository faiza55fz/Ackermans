NASA FIRMS Active-Fire Cleaned Detections (Palisades Test Data - Winter Only)

- Temporary winter-only version (Dec to Feb) for pipeline testing, about 4,560 rows.
- MODIS from 2005, VIIRS from 2013, all SP, no autumn months and no NRT rows.
- A full-year version with the same 23 columns will replace it, and only the row counts will change.
- Columns: region, sensor, satellite, processing, datetime_utc, date, year, latitude, longitude, confidence, confidence_class, frp, daynight, scan, track, instrument, version, brightness, bright_t31, bright_ti4, bright_ti5, type, is_vegetation_fire.
- confidence is text in the combined file. MODIS rows leave bright_ti4 and bright_ti5 empty, and VIIRS rows leave brightness and bright_t31 empty.
- Do not use it for the burning calendar, medians or MODIS/VIIRS harmonization.
